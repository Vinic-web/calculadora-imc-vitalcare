import { Link, useNavigate, useLocation } from 'react-router-dom';
import { useState, useEffect } from 'react';

function Navbar() {
  const navigate = useNavigate();
  const location = useLocation();
  const [usuarioLogado, setUsuarioLogado] = useState(null);

  useEffect(() => {
    // Verifica se há usuário logado
    const usuario = JSON.parse(localStorage.getItem('usuarioLogado'));
    setUsuarioLogado(usuario);
  }, [location]); // Atualiza quando a rota muda

  const handleLogout = () => {
    localStorage.removeItem('usuarioLogado');
    setUsuarioLogado(null);
    navigate('/login');
  };

  return (
    <nav style={{
      backgroundColor: '#74121D',
      padding: '1rem 2rem',
      display: 'flex',
      justifyContent: 'space-between',
      alignItems: 'center',
      boxShadow: '0 2px 10px rgba(0,0,0,0.1)'
    }}>
      <Link to="/" style={{
        color: 'white',
        fontSize: '1.8rem',
        fontWeight: 'bold',
        textDecoration: 'none'
      }}>
        VitalCare
      </Link>

      <div style={{
        display: 'flex',
        gap: '2rem',
        alignItems: 'center'
      }}>
        <Link to="/" style={{
          color: 'white',
          textDecoration: 'none',
          fontSize: '1.1rem',
          fontWeight: '500',
          transition: 'opacity 0.3s'
        }}
        onMouseOver={(e) => e.target.style.opacity = '0.8'}
        onMouseOut={(e) => e.target.style.opacity = '1'}
        >
          Home
        </Link>

        {usuarioLogado ? (
          <>
            <Link to="/imc" style={{
              color: 'white',
              textDecoration: 'none',
              fontSize: '1.1rem',
              fontWeight: '500',
              transition: 'opacity 0.3s'
            }}
            onMouseOver={(e) => e.target.style.opacity = '0.8'}
            onMouseOut={(e) => e.target.style.opacity = '1'}
            >
              Calcular IMC
            </Link>

            <div style={{
              display: 'flex',
              alignItems: 'center',
              gap: '1rem'
            }}>
              <span style={{
                color: 'white',
                fontSize: '1rem'
              }}>
                Olá, {usuarioLogado.nome.split(' ')[0]}!
              </span>

              <button
                onClick={handleLogout}
                style={{
                  backgroundColor: '#C52233',
                  color: 'white',
                  border: 'none',
                  padding: '0.6rem 1.5rem',
                  borderRadius: '5px',
                  cursor: 'pointer',
                  fontSize: '1rem',
                  fontWeight: '600',
                  transition: 'background-color 0.3s'
                }}
                onMouseOver={(e) => e.target.style.backgroundColor = '#A51C30'}
                onMouseOut={(e) => e.target.style.backgroundColor = '#C52233'}
              >
                Sair
              </button>
            </div>
          </>
        ) : (
          <Link to="/login" style={{
            backgroundColor: '#C52233',
            color: 'white',
            textDecoration: 'none',
            padding: '0.6rem 1.5rem',
            borderRadius: '5px',
            fontSize: '1rem',
            fontWeight: '600',
            transition: 'background-color 0.3s',
            display: 'inline-block'
          }}
          onMouseOver={(e) => e.target.style.backgroundColor = '#A51C30'}
          onMouseOut={(e) => e.target.style.backgroundColor = '#C52233'}
          >
            Login
          </Link>
        )}
      </div>
    </nav>
  );
}

export default Navbar;