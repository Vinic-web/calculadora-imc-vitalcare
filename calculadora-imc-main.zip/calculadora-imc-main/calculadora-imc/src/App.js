import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import Navbar from './components/navbar';
import Home from './pages/home';
import IMC from './pages/IMC';
import Login from './pages/login';
import Cadastro from './pages/cadastro';
import NotFound from './pages/NotFound';

// Componente para proteger rotas
function RotaProtegida({ children }) {
  const usuarioLogado = localStorage.getItem('usuarioLogado');
  
  if (!usuarioLogado) {
    return <Navigate to="/login" replace />;
  }
  
  return children;
}

function App() {
  return (
    <BrowserRouter>
      <Navbar />
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/login" element={<Login />} />
        <Route path="/cadastro" element={<Cadastro />} />
        
        {/* Rota protegida - só acessa se estiver logado */}
        <Route 
          path="/imc" 
          element={
            <RotaProtegida>
              <IMC />
            </RotaProtegida>
          } 
        />
        
        <Route path="*" element={<NotFound />} />
      </Routes>
    </BrowserRouter>
  );
}

export default App;