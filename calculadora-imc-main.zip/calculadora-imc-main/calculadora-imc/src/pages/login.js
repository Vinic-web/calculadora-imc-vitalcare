import { useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';

function Login() {
  const [email, setEmail] = useState('');
  const [senha, setSenha] = useState('');
  const [erro, setErro] = useState('');
  const navigate = useNavigate();

  const handleLogin = (e) => {
    e.preventDefault();
    
    // Busca os usuários cadastrados
    const usuariosCadastrados = JSON.parse(localStorage.getItem('usuarios') || '[]');
    
    // Verifica se o usuário existe
    const usuarioEncontrado = usuariosCadastrados.find(
      u => u.email === email && u.senha === senha
    );
    
    if (usuarioEncontrado) {
      // Salva que o usuário está logado
      localStorage.setItem('usuarioLogado', JSON.stringify(usuarioEncontrado));
      navigate('/imc'); // Redireciona para a página do IMC
    } else {
      setErro('Email ou senha incorretos!');
    }
  };

  return (
    <div style={{
      minHeight: '90vh',
      background: 'linear-gradient(135deg, #580C1F 0%, #74121D 100%)',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      padding: '2rem'
    }}>
      <div style={{
        backgroundColor: 'white',
        padding: '3rem',
        borderRadius: '20px',
        boxShadow: '0 10px 40px rgba(0,0,0,0.2)',
        width: '100%',
        maxWidth: '450px'
      }}>
        <h1 style={{
          color: '#74121D',
          textAlign: 'center',
          marginBottom: '0.5rem',
          fontSize: '2.5rem'
        }}>
          VitalCare
        </h1>
        <p style={{
          textAlign: 'center',
          color: '#666',
          marginBottom: '2rem',
          fontSize: '1.1rem'
        }}>
          Faça login para continuar
        </p>

        <form onSubmit={handleLogin}>
          <div style={{ marginBottom: '1.5rem' }}>
            <label style={{
              display: 'block',
              marginBottom: '0.5rem',
              color: '#2c3e50',
              fontWeight: '600'
            }}>
              Email
            </label>
            <input
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="seu@email.com"
              required
              style={{
                width: '100%',
                padding: '1rem',
                fontSize: '1rem',
                border: '2px solid #e0e0e0',
                borderRadius: '8px',
                outline: 'none',
                boxSizing: 'border-box',
                transition: 'border-color 0.3s'
              }}
              onFocus={(e) => e.target.style.borderColor = '#C52233'}
              onBlur={(e) => e.target.style.borderColor = '#e0e0e0'}
            />
          </div>

          <div style={{ marginBottom: '1.5rem' }}>
            <label style={{
              display: 'block',
              marginBottom: '0.5rem',
              color: '#2c3e50',
              fontWeight: '600'
            }}>
              Senha
            </label>
            <input
              type="password"
              value={senha}
              onChange={(e) => setSenha(e.target.value)}
              placeholder="••••••••"
              required
              style={{
                width: '100%',
                padding: '1rem',
                fontSize: '1rem',
                border: '2px solid #e0e0e0',
                borderRadius: '8px',
                outline: 'none',
                boxSizing: 'border-box',
                transition: 'border-color 0.3s'
              }}
              onFocus={(e) => e.target.style.borderColor = '#C52233'}
              onBlur={(e) => e.target.style.borderColor = '#e0e0e0'}
            />
          </div>

          {erro && (
            <div style={{
              backgroundColor: '#fee',
              color: '#c33',
              padding: '1rem',
              borderRadius: '8px',
              marginBottom: '1.5rem',
              textAlign: 'center',
              fontSize: '0.95rem'
            }}>
              {erro}
            </div>
          )}

          <button
            type="submit"
            style={{
              width: '100%',
              padding: '1.2rem',
              fontSize: '1.1rem',
              fontWeight: '600',
              color: 'white',
              backgroundColor: '#C52233',
              border: 'none',
              borderRadius: '8px',
              cursor: 'pointer',
              transition: 'all 0.3s ease',
              marginBottom: '1rem'
            }}
            onMouseOver={(e) => e.target.style.backgroundColor = '#A51C30'}
            onMouseOut={(e) => e.target.style.backgroundColor = '#C52233'}
          >
            Entrar
          </button>

          <p style={{
            textAlign: 'center',
            color: '#666',
            fontSize: '0.95rem'
          }}>
            Não tem uma conta?{' '}
            <Link to="/cadastro" style={{
              color: '#C52233',
              textDecoration: 'none',
              fontWeight: '600'
            }}>
              Cadastre-se
            </Link>
          </p>
        </form>
      </div>
    </div>
  );
}

export default Login;